import { useEffect, useState } from "react";
import { Link } from "wouter";
import { CheckCircle2, LogIn, UserRound } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { getOAuthReturnUrl } from "@/lib/oauthReturn";

export default function CustomerProfilePage() {
  const [loading, setLoading] = useState(true);
  const [signedIn, setSignedIn] = useState(false);
  const [name, setName] = useState("");
  const [notice, setNotice] = useState("");

  useEffect(() => {
    void (async () => {
      if (!supabase) { setLoading(false); return; }
      const { data } = await supabase.auth.getUser();
      if (!data.user) { setLoading(false); return; }
      setSignedIn(true);
      const { data: profile } = await supabase.from("profiles").select("display_name").eq("id", data.user.id).maybeSingle();
      setName(profile?.display_name ?? "");
      setLoading(false);
    })();
  }, []);

  async function signIn() {
    if (!supabase) return;
    const redirectTo = getOAuthReturnUrl("/perfil");
    await supabase.auth.signInWithOAuth({ provider: "google", options: { redirectTo } });
  }

  async function save() {
    if (!supabase || !name.trim()) return;
    const { data } = await supabase.auth.getUser();
    if (!data.user) return;
    const { error } = await supabase.from("profiles").update({ display_name: name.trim() }).eq("id", data.user.id);
    setNotice(error ? "Não foi possível salvar agora. Tente novamente." : "Nome completo salvo. Este será o nome usado nos seus pedidos.");
  }

  if (loading) return <main className="container py-16 text-white/60">Carregando seu cadastro…</main>;
  return <main className="container max-w-xl py-10 md:py-16"><Link href="/" className="text-sm text-white/55 hover:text-[#7affb9]">← Voltar para a loja</Link><section className="mt-6 rounded-3xl border border-white/10 bg-white/[.025] p-6 sm:p-8"><p className="eyebrow">MINHA CONTA</p><h1 className="mt-2 text-3xl font-black">SEU CADASTRO</h1><p className="mt-3 text-sm leading-6 text-white/60">O Google serve apenas para entrar com segurança. Informe abaixo o seu nome completo; ele é o nome que a loja verá no pedido.</p>{!signedIn ? <button onClick={() => void signIn()} className="button-primary mt-7 w-full"><LogIn size={17} /> ENTRAR COM GOOGLE</button> : <div className="mt-7"><label className="text-sm font-semibold" htmlFor="fullName">Nome completo</label><input id="fullName" value={name} onChange={(event) => setName(event.target.value)} placeholder="Digite seu nome completo" className="mt-2 w-full rounded-xl border border-white/15 bg-black/20 px-4 py-3 text-white outline-none focus:border-[#7affb9]" /><button onClick={() => void save()} disabled={!name.trim()} className="button-primary mt-4 w-full"><UserRound size={17} /> SALVAR MEU NOME</button>{notice && <p role="status" className="mt-4 flex gap-2 text-sm text-[#7affb9]"><CheckCircle2 size={17} />{notice}</p>}</div>}</section></main>;
}
