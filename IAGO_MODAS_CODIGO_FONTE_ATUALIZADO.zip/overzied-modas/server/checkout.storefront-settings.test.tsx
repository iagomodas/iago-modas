// @vitest-environment jsdom
import React from "react";
import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

const { storefrontSettings } = vi.hoisted(() => ({
  storefrontSettings: {
    local_city: "Maceió",
    local_state: "AL",
    local_pickup_enabled: true,
    local_delivery_enabled: true,
    local_pickup_label: "Buscar na loja em",
    local_delivery_label: "Motoboy disponível em",
    outside_delivery_label: "Moro fora da cidade",
    outside_delivery_notice: "O frete é confirmado no Direct antes da postagem.",
    pix_key: "pix-atualizado@exemplo.com",
  },
}));

vi.mock("@/contexts/StoreContext", () => ({
  useStore: () => ({
    cart: [{ id: 1, name: "Camiseta teste", size: "M", quantity: 1, price: 89.9, image: "https://images.example.com/camiseta.jpg" }],
    subtotal: 89.9,
  }),
}));
vi.mock("@/hooks/useStorefrontSettings", () => ({ useStorefrontSettings: () => ({ settings: storefrontSettings }) }));
vi.mock("@/lib/catalog", () => ({ toMoney: (value: number) => `R$ ${value.toFixed(2).replace(".", ",")}` }));
vi.mock("@/lib/instagramOrder", () => ({ formatInstagramOrder: () => "Pedido de teste", openInstagramApp: vi.fn() }));
vi.mock("@/lib/supabase", () => ({ supabase: null }));
vi.mock("wouter", () => ({ Link: ({ children }: { children: React.ReactNode }) => <a href="#">{children}</a> }));

import CheckoutPage from "../client/src/pages/CheckoutPage";

describe("checkout com configurações da vitrine", () => {
  it("renderiza os textos de entrega e a chave Pix definidos pelo administrador", () => {
    render(<CheckoutPage />);

    expect(screen.getByText("Buscar na loja em Maceió — AL")).toBeTruthy();
    expect(screen.getByText("Motoboy disponível em Maceió — AL")).toBeTruthy();
    expect(screen.getByText("Moro fora da cidade")).toBeTruthy();
    expect(screen.getAllByText("O frete é confirmado no Direct antes da postagem.")).toHaveLength(2);
    expect(screen.getByText("pix-atualizado@exemplo.com")).toBeTruthy();
  });
});
