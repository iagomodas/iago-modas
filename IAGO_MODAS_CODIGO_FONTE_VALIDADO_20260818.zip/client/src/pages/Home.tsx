import ProductCard from "@/components/ProductCard";
import { useStore } from "@/contexts/StoreContext";
import { useCatalog } from "@/hooks/useCatalog";
import { useStorefrontSettings } from "@/hooks/useStorefrontSettings";
import { heroImage } from "@/lib/inlineHeroAsset";
import { logoImage } from "@/lib/inlineLogoAsset";
import { instagramDirectUrl } from "@/lib/instagramOrder";
import { storefrontPath } from "@/lib/storefront";
import { ArrowRight, Box, Headphones, MessageCircle, ShieldCheck, Sparkles } from "lucide-react";
import { useEffect, useMemo, useState, type CSSProperties } from "react";
import { FaInstagram } from "react-icons/fa";
import { Link } from "wouter";

export default function Home() {
  const { setCartOpen } = useStore();
  const { products: catalogProducts } = useCatalog();
  const { settings } = useStorefrontSettings();
  const configuredLogo = settings.logo_url?.trim();
  const currentLogo = configuredLogo && !configuredLogo.startsWith("/manus-storage/") ? configuredLogo : logoImage;
  const highlights = catalogProducts.slice(0, 4);
  const benefits = [
    { icon: FaInstagram, title: settings.benefit_one_title, caption: settings.benefit_one_caption },
    { icon: Box, title: settings.benefit_two_title, caption: settings.benefit_two_caption },
    { icon: Headphones, title: settings.benefit_three_title, caption: settings.benefit_three_caption },
    { icon: ShieldCheck, title: settings.benefit_four_title, caption: settings.benefit_four_caption },
  ];
  const fallbackHero = `${import.meta.env.BASE_URL}assets/overzied-hero.jpg`;
  const [heroSrc, setHeroSrc] = useState(settings.hero_image_url ?? fallbackHero);
  const heroLines = useMemo(() => settings.hero_title.split(/\r?\n/).filter(Boolean), [settings.hero_title]);
  const themeStyle = { "--store-primary": settings.primary_color, "--store-background": settings.background_color } as CSSProperties;

  useEffect(() => {
    setHeroSrc(settings.hero_image_url ?? fallbackHero);
  }, [fallbackHero, settings.hero_image_url]);

  return (
    <main style={themeStyle} className="bg-[var(--store-background)]">
      {settings.hero_visible && <section className="relative isolate overflow-hidden border-b border-white/10">
        <div className="container grid min-h-[610px] items-center gap-8 py-14 lg:grid-cols-[.98fr_1.02fr] lg:py-16">
          <div className="relative z-10 max-w-xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-[var(--store-primary)]/30 bg-[var(--store-primary)]/5 px-3 py-1.5 text-[10px] font-bold tracking-[.18em] text-[var(--store-primary)]">
              <Sparkles size={13} /> {settings.hero_eyebrow}
            </div>
            <h1 className="display-title mt-7">
              {heroLines.map((line, index) => (
                <span className={line.includes(settings.hero_accent) ? "text-[var(--store-primary)]" : undefined} key={`${line}-${index}`}>
                  {line}
                  {index < heroLines.length - 1 && <br />}
                </span>
              ))}
            </h1>
            <p className="mt-6 max-w-lg text-base leading-7 text-white/65">{settings.hero_description}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href={storefrontPath(settings.hero_cta_path)} className="button-primary">
                {settings.hero_cta_label} <ArrowRight size={17} />
              </Link>
              <a className="button-secondary" target="_blank" rel="noreferrer" href={instagramDirectUrl}>
                <FaInstagram aria-hidden="true" size={17} /> FALAR NO INSTAGRAM
              </a>
            </div>
            <div className="mt-10 flex items-center gap-4">
              <img src={currentLogo} alt="Logo IAGO MODAS" className="h-12 w-12 rounded-full object-cover opacity-85" />
              <p className="border-l border-white/15 pl-4 text-xs leading-5 text-white/45">
                IAGO MODAS<br /><span className="text-white/70">MODA QUE REPRESENTA VOCÊ.</span>
              </p>
            </div>
          </div>
          <div className="relative mx-auto w-full max-w-[600px] lg:mr-0">
            <div className="absolute -inset-12 rounded-full bg-[var(--store-primary)]/10 blur-[90px]" />
            <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-[#12171b] p-2 shadow-[0_25px_80px_rgba(0,0,0,.45)]">
              <img src={heroSrc} onError={() => setHeroSrc(heroImage)} alt="Modelo vestindo moda urbana IAGO MODAS" className="aspect-[4/4.6] w-full rounded-[1.55rem] object-cover object-right" />
              <div className="absolute bottom-8 left-8 rounded-xl border border-white/10 bg-black/60 px-4 py-3 backdrop-blur">
                <p className="text-[9px] font-bold tracking-[.2em] text-[var(--store-primary)]">CURADORIA IM</p>
                <p className="mt-1 text-sm font-semibold">Moda urbana premium</p>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_15%_25%,rgba(59,255,160,.1),transparent_26%),linear-gradient(110deg,#0a0d10_0%,#0e1419_60%,#080a0c_100%)]" />
      </section>}

      {settings.benefits_visible && <section className="border-b border-white/10 bg-[var(--store-background)]">
        <div className="container grid divide-y divide-white/10 sm:grid-cols-2 sm:divide-x sm:divide-y-0 lg:grid-cols-4">
          {benefits.map(({ icon: Icon, title, caption }) => (
            <div key={title} className="flex items-center gap-3 px-3 py-6 sm:px-5">
              <span className="flex h-9 w-9 items-center justify-center rounded-full border border-white/15 bg-white/[.03] text-[var(--store-primary)]"><Icon size={17} /></span>
              <div><p className="text-sm font-semibold">{title}</p><p className="mt-0.5 text-xs text-white/45">{caption}</p></div>
            </div>
          ))}
        </div>
      </section>}

      {settings.promotion_visible && <section className="container py-16 md:py-24">
        <div className="offer-panel overflow-hidden rounded-[2rem] p-7 md:p-11">
          <div className="relative z-10 max-w-xl">
            <p className="eyebrow text-[var(--store-primary)]">{settings.promotion_eyebrow}</p>
            <h2 className="mt-3 text-4xl font-black uppercase tracking-tight sm:text-5xl">{settings.promotion_title}<br /><span className="text-white/55">{settings.promotion_accent}</span></h2>
            <p className="mt-4 max-w-md text-sm leading-6 text-white/65">{settings.promotion_description}</p>
            <Link href={storefrontPath(settings.promotion_cta_path)} className="button-primary mt-7">{settings.promotion_cta_label} <ArrowRight size={17} /></Link>
          </div>
          <div className="absolute -bottom-24 -right-8 hidden h-80 w-80 rounded-full border-[38px] border-[var(--store-primary)]/15 lg:block" />
        </div>
      </section>}

      {settings.highlights_visible && <section className="container pb-16">
        <div className="flex flex-wrap items-end justify-between gap-4"><div><p className="eyebrow">{settings.highlights_eyebrow}</p><h2 className="section-title mt-2">{settings.highlights_title}</h2></div><Link href={storefrontPath(settings.highlights_cta_path)} className="text-sm font-semibold text-[var(--store-primary)] transition hover:text-white">{settings.highlights_cta_label} <ArrowRight className="inline" size={15} /></Link></div>
        <p className="mt-4 max-w-2xl text-sm leading-6 text-white/52">{settings.highlights_description}</p>
        <div className="mt-8 grid grid-cols-2 gap-x-4 gap-y-9 md:grid-cols-3 lg:grid-cols-4">{highlights.map((product) => <ProductCard key={product.id} product={product} />)}</div>
      </section>}

      {settings.newsletter_visible && <section className="container py-16 md:py-24">
        <div className="grid items-center gap-8 rounded-[2rem] border border-white/10 bg-white/[.025] p-7 md:grid-cols-[1fr_auto] md:p-10"><div><p className="eyebrow">NOVIDADES</p><h2 className="section-title mt-2">{settings.newsletter_title}</h2><p className="mt-3 max-w-xl text-sm leading-6 text-white/55">{settings.newsletter_description}</p></div><form onSubmit={(event) => { event.preventDefault(); setCartOpen(true); }} className="flex w-full max-w-md gap-2"><input required type="email" placeholder="Seu melhor e-mail" className="h-12 min-w-0 flex-1 rounded-xl border border-white/15 bg-black/20 px-4 text-sm outline-none transition focus:border-[var(--store-primary)]" /><button className="button-primary shrink-0">QUERO RECEBER</button></form></div>
      </section>}
      <a href={instagramDirectUrl} target="_blank" rel="noreferrer" aria-label="Falar pelo Instagram" className="instagram-float"><FaInstagram aria-hidden="true" size={21} /><span>ATENDIMENTO</span></a>
    </main>
  );
}
