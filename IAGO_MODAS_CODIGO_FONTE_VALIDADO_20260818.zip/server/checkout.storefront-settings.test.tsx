// @vitest-environment jsdom
import React from "react";
import { act, cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const { storefrontSettings } = vi.hoisted(() => ({
  storefrontSettings: {
    local_city: "Maceió",
    local_state: "AL",
    local_pickup_enabled: true,
    local_delivery_enabled: true,
    local_pickup_label: "Buscar na loja em",
    local_delivery_label: "Motoboy disponível em",
    outside_delivery_label: "Moro fora da cidade",
    outside_delivery_notice: "O frete é confirmado no Direct antes da postagem.",
    pix_key: "pix-atualizado@exemplo.com",
  },
}));

const { getUser, maybeSingle, rpc, clipboardWrite, supabaseClient } = vi.hoisted(() => {
  const getUser = vi.fn();
  const maybeSingle = vi.fn();
  const rpc = vi.fn();
  const clipboardWrite = vi.fn();
  return {
    getUser,
    maybeSingle,
    rpc,
    clipboardWrite,
    supabaseClient: {
      auth: { getUser },
      from: vi.fn(() => ({
        select: vi.fn(() => ({
          eq: vi.fn(() => ({ maybeSingle })),
        })),
      })),
      rpc,
    },
  };
});

vi.mock("@/contexts/StoreContext", () => ({
  useStore: () => ({
    cart: [{ id: 1, name: "Camiseta teste", size: "M", quantity: 1, price: 89.9, image: "https://images.example.com/camiseta.jpg" }],
    subtotal: 89.9,
  }),
}));
vi.mock("@/hooks/useStorefrontSettings", () => ({ useStorefrontSettings: () => ({ settings: storefrontSettings }) }));
vi.mock("@/lib/catalog", () => ({ toMoney: (value: number) => `R$ ${value.toFixed(2).replace(".", ",")}` }));
vi.mock("@/lib/instagramOrder", () => ({ formatInstagramOrder: () => "Pedido de teste", openInstagramApp: vi.fn() }));
vi.mock("@/lib/supabase", () => ({ supabase: supabaseClient }));
vi.mock("wouter", () => ({ Link: ({ children }: { children: React.ReactNode }) => <a href="#">{children}</a> }));

import CheckoutPage from "../client/src/pages/CheckoutPage";

describe("checkout com configurações da vitrine", () => {
  beforeEach(() => {
    getUser.mockResolvedValue({ data: { user: null } });
    maybeSingle.mockResolvedValue({ data: null });
    rpc.mockResolvedValue({ data: [{ order_number: "IM-0001" }], error: null });
    clipboardWrite.mockResolvedValue(undefined);
    Object.defineProperty(navigator, "clipboard", { configurable: true, value: { writeText: clipboardWrite } });
    window.location.hash = "";
  });

  afterEach(() => {
    cleanup();
    vi.useRealTimers();
  });

  it("renderiza os textos de entrega e a chave Pix definidos pelo administrador", () => {
    render(<CheckoutPage />);

    expect(screen.getByText("Buscar na loja em Maceió — AL")).toBeTruthy();
    expect(screen.getByText("Motoboy disponível em Maceió — AL")).toBeTruthy();
    expect(screen.getByText("Moro fora da cidade")).toBeTruthy();
    expect(screen.getAllByText("O frete é confirmado no Direct antes da postagem.")).toHaveLength(2);
    expect(screen.getByText("pix-atualizado@exemplo.com")).toBeTruthy();
  });

  it("bloqueia o pedido de cliente autenticado sem nome completo salvo e direciona ao perfil", async () => {
    getUser.mockResolvedValue({ data: { user: { id: "cliente-sem-perfil", email: "cliente@exemplo.com" } } });
    maybeSingle.mockResolvedValue({ data: null });
    render(<CheckoutPage />);

    await waitFor(() => expect(screen.getByText(/complete seu cadastro com google/i)).toBeTruthy());
    vi.useFakeTimers();
    fireEvent.click(screen.getByRole("button", { name: /enviar pedido e abrir instagram/i }));

    expect(screen.getByRole("status").textContent).toContain("Entre com Google e informe seu nome completo antes de enviar o pedido.");
    act(() => { vi.advanceTimersByTime(850); });
    expect(window.location.hash).toBe("#/perfil");
    expect(rpc).not.toHaveBeenCalled();
  });

  it("libera o pedido depois que o nome completo próprio está salvo no perfil", async () => {
    getUser.mockResolvedValue({ data: { user: { id: "cliente-com-perfil", email: "cliente@exemplo.com" } } });
    maybeSingle.mockResolvedValue({ data: { display_name: "Maria da Silva" } });
    render(<CheckoutPage />);

    await waitFor(() => expect(screen.getByText("Maria da Silva")).toBeTruthy());
    fireEvent.click(screen.getByRole("button", { name: /registrar e copiar resumo/i }));

    await waitFor(() => expect(rpc).toHaveBeenCalledWith("create_manual_delivery_order", expect.objectContaining({
      p_customer_name: "Maria da Silva",
      p_customer_email: "cliente@exemplo.com",
      p_delivery_mode: "local",
    })));
    expect(screen.getByRole("status").textContent).toContain("Pedido IM-0001 registrado");
    expect(window.location.hash).toBe("");
  });

  it("preenche o endereço dos Correios apenas com os dados salvos do próprio perfil e mantém a edição disponível", async () => {
    getUser.mockResolvedValue({ data: { user: { id: "cliente-com-endereco", email: "cliente@exemplo.com" } } });
    maybeSingle.mockResolvedValue({ data: {
      display_name: "Maria da Silva",
      delivery_phone: "82999990000",
      delivery_postal_code: "57000000",
      delivery_street: "Rua das Flores",
      delivery_number: "25",
      delivery_complement: "Casa",
      delivery_district: "Centro",
      delivery_city: "Maceió",
      delivery_state: "AL",
    } });
    render(<CheckoutPage />);

    await waitFor(() => expect(screen.getByText("Maria da Silva")).toBeTruthy());
    fireEvent.click(screen.getByLabelText("Moro fora da cidade"));

    expect((screen.getByPlaceholderText("CEP") as HTMLInputElement).value).toBe("57000000");
    expect((screen.getByPlaceholderText("Rua ou avenida") as HTMLInputElement).value).toBe("Rua das Flores");
    fireEvent.change(screen.getByPlaceholderText("Número"), { target: { value: "30" } });
    expect((screen.getByPlaceholderText("Número") as HTMLInputElement).value).toBe("30");

    fireEvent.click(screen.getByRole("button", { name: /registrar e copiar resumo/i }));
    await waitFor(() => expect(rpc).toHaveBeenCalledWith("create_manual_delivery_order", expect.objectContaining({
      p_customer_phone: "82999990000",
      p_postal_code: "57000000",
      p_address: "Rua das Flores",
      p_delivery_number: "30",
      p_delivery_mode: "correios",
    })));
  });
});
