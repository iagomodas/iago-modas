# Validação da publicação pública — 18 de agosto de 2026

## Ocorrência corrigida

A URL pública da IAGO MODAS apresentava uma tela branca porque o `index.html` da branch `gh-pages` fazia referência a arquivos JavaScript e CSS externos que não existiam nessa publicação.

## Ação executada

Foi gerado novamente o build estático com a base `/iago-modas/` e, em seguida, um HTML consolidado com JavaScript, CSS e imagens incorporados. O arquivo `index.html` corrigido foi enviado diretamente à branch `gh-pages` no commit `a85256a`.

## Evidências de validação

| Verificação | Resultado |
| --- | --- |
| Conteúdo da branch `gh-pages` | O HTML consolidado contém JavaScript incorporado e não referencia `assets/index-*.js` ou `assets/index-*.css`. |
| Conteúdo servido pelo GitHub Pages | O HTML atualizado foi identificado após a propagação. |
| Página inicial pública | A vitrine da IAGO MODAS renderizou normalmente, com cabeçalho, categorias, carrinho e produtos visíveis. |
| Página de perfil pública | A rota `#/perfil` carregou o formulário com nome completo e campos de entrega. |
| Painel administrativo | A rota `#/admin` carregou o painel autenticado do proprietário, incluindo vitrine, catálogo, pedidos e etiquetas. |
| Testes automatizados | `pnpm test` concluiu com 27 arquivos e 68 testes aprovados. |
| Manutenção do Supabase | O workflow diário agendado executou com sucesso na branch `main` em 7 segundos, validando secrets e o catálogo público sem modificar dados. |
| Sincronização do código | A branch isolada `sync/iago-modas-validated-20260818` foi criada a partir de `main`. O envio automatizado de commits foi bloqueado por autorização 403 da integração, sem afetar as branches públicas existentes. |

## URL validada

<https://iagomodas.github.io/iago-modas/>
