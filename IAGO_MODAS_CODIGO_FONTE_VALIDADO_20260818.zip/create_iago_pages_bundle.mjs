import { readFile, writeFile, readdir } from 'node:fs/promises';

const projectRoot = '/home/ubuntu/overzied-modas';
const publicRoot = `${projectRoot}/dist/public`;
const assetFiles = await readdir(`${publicRoot}/assets`);
const cssFile = assetFiles.find((file) => file.startsWith('index-') && file.endsWith('.css'));
const javascriptFile = assetFiles.find((file) => file.startsWith('index-') && file.endsWith('.js'));

if (!cssFile || !javascriptFile) {
  throw new Error('Não foi possível localizar os arquivos CSS e JavaScript do build estático.');
}

const [html, css, javascript, hero, logo] = await Promise.all([
  readFile(`${publicRoot}/index.html`, 'utf8'),
  readFile(`${publicRoot}/assets/${cssFile}`, 'utf8'),
  readFile(`${publicRoot}/assets/${javascriptFile}`, 'utf8'),
  readFile(`${publicRoot}/assets/overzied-hero.jpg`),
  readFile('/home/ubuntu/webdev-static-assets/iago-modas-logo-instagram.png'),
]);

const heroDataUri = `data:image/jpeg;base64,${hero.toString('base64')}`;
const logoDataUri = `data:image/png;base64,${logo.toString('base64')}`;
const bundledJavascript = javascript
  .replace(/\/[^/]+\/assets\/overzied-hero\.jpg/g, heroDataUri)
  .replaceAll('/manus-storage/iago-modas-logo-instagram_c08296de.png', logoDataUri);
const javascriptDataUri = `data:text/javascript;base64,${Buffer.from(bundledJavascript, 'utf8').toString('base64')}`;

const consolidated = html
  .replace(/<script type="module" crossorigin src="[^"]+"><\/script>/, `<script type="module" src="${javascriptDataUri}"></script>`)
  .replace(/<link rel="stylesheet" crossorigin href="[^"]+">/, `<style>${css}</style>`);

await writeFile('/home/ubuntu/webdev-static-assets/iago-modas-github-pages.html', consolidated, 'utf8');
console.log('Arquivo estático consolidado criado com sucesso.');
